BMP180
======
Forked from Sparkfun.
Arduino library for BMP180 Bosch barometric pressure/temperature sensors.
Install as usual in your Arduino/libraries folder, restart IDE.