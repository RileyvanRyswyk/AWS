SI7021
======

Arduino library for SI7020 and SI7021 environmental sensors
Install as usual in your Arduino/libraries folder, restart IDE.